from django.apps import AppConfig


class SpiderConfig(AppConfig):
    name = 'spider'
